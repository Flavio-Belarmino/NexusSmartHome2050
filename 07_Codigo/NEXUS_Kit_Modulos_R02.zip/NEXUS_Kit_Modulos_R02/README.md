# Casa Inteligente | NEXUS | ExpoTech

Kit de módulos R02, 05/11/2026.

Começar pelo [guia e ordem dos ensaios](10_Documentacao/Guia_Bancada_Modulos.md). Cada sketch é independente; carregar outro no Mega substitui o anterior.

- [Primeiro ensaio A01](07_Codigo/NEXUS_A01_Bancada/README.md).
- [Brise A02](07_Codigo/NEXUS_A02_Brise/README.md).
- [RFID A03](07_Codigo/NEXUS_A03_RFID/README.md).
- [Ambiente A04](07_Codigo/NEXUS_A04_Ambiente/README.md).
- [Água A05](07_Codigo/NEXUS_A05_Agua/README.md).
- [Botões/LEDs A08](07_Codigo/NEXUS_A08_Botoes/README.md).
- [Entradas/touch A09](07_Codigo/NEXUS_A09_Entradas/README.md).
- [Simulador da garagem A07](09_Simulacoes/Garagem/NEXUS_Garagem_Simulador.html): abrir no navegador.
- [Supervisor USB](07_Codigo/Supervisor_USB/README.md).
- [Estudo solar](06_Calculos/Solar/README.md).
- [Validação em computador](07_Codigo/Testes_Modulos/Validacao_Modulos_R02.md).

Os programas foram compilados/testados conforme o registro, sem teste físico. A bomba e a solenoide não são energizadas por esses sketches. A garagem é uma simulação de sequência, sem mecanismo real.
